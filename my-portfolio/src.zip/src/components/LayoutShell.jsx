// src/components/LayoutShell.jsx
// Wraps the app with HeaderNameVisibilityProvider + Header + <main>.

import * as React from "react";
import { Box, Link as MuiLink } from "@mui/material";
import Header from "./Header.jsx";
import { HeaderNameVisibilityProvider } from "../context/HeaderNameContext.jsx";

export default function LayoutShell({ mode, setMode, children }) {
  return (
    <HeaderNameVisibilityProvider>
      {/* Skip link for keyboard users */}
      <MuiLink
        href="#main"
        sx={(t) => ({
          position: "fixed",
          left: t.spacing(2),
          top: t.spacing(2),
          zIndex: t.zIndex.tooltip + 1,
          transform: "translateY(-200%)",
          "&:focus-visible": {
            transform: "translateY(0)",
            backgroundColor: t.palette.background.paper,
            padding: t.spacing(0.5, 1.5),
            borderRadius: 999,
            boxShadow: t.shadows[2],
          },
        })}
      >
        Skip to main content
      </MuiLink>

      <Header mode={mode} setMode={setMode} />

      <Box
        component="main"
        id="main"
        sx={{
          pt: { xs: 4, sm: 6 }, // pushes content below fixed header
        }}
      >
        {children}
      </Box>
    </HeaderNameVisibilityProvider>
  );
}
